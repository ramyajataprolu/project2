package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

	//@controller is a predefined annotation which we need to specified for our class to be act like as controller 
	@Controller
	public class HomeController 
	{
		
	//request mapping is also predefined a annotation for map the address which jsp page //u need to execute .
	//here in these example my home page should display as soon as I will run my project 
	//Without giving a extension of jsp page

		@RequestMapping("/")
	//user defined function which return a ModelAndView object .
		public ModelAndView LandingPage()
		{
	//creating a object for modelandview class and passing the parameter for //jsp page . without extension of jsp page. It will execute your main //page.
			return new ModelAndView("Home");
			
		}

	}

