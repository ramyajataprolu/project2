
var app = angular.module('quizApp', []);

app.directive('quiz', function(quizFactory) {
	return {
		restrict: 'AE',
		scope: {},
		templateUrl: 'template.html',
		link: function(scope, elem, attrs) {
			scope.start = function() {
				scope.id = 0;
				scope.quizOver = false;
				scope.inProgress = true;
				scope.getQuestion();
			};

			scope.reset = function() {
				scope.inProgress = false;
				scope.score =0;
				scope.score++;
				
			}

			scope.getQuestion = function() {
				var q = quizFactory.getQuestion(scope.id);
				if(q) {
					scope.question = q.question;
					scope.options = q.options;
					/*scope.answer = q.answer;*/
					/*scope.answerMode = true;*/
				} else {
					scope.quizOver = true;
				}
			};

			scope.checkAnswer = function() {
				if(!$('input[name=options]:checked').length) return;

				var ans = $('input[name=options]:checked').val();

				if(ans == scope.options[scope.options]) {
					scope.score =1;
					scope.score++;
					
				/*	scope.correctAns = true;*/
				}/* else {
					scope.correctAns = false;
				}*/

			/*scope.answerMode = false;*/
			};

			scope.nextQuestion = function() {
				scope.id++;
				scope.getQuestion();
			}

			scope.reset();
		}
	}
});

app.factory('quizFactory', function() {
	var questions = [
		{
			question: "Which is ypur favourite color?",
			options: ["red ", "blue ", "green", "black"],
			
		},
		{
			question: "What is your favourite cuisine?",
			options: ["japanese", "mumbai ", "south indian ", "north indian"],
			
		},
		{
			question: "Which is your prefered mobile os ?",
			options: ["android ", "ios", "windows", "firefox"],
			
		},
		{
			question: "Which is the most popular consumer brand in india?",
			options: ["pidilite", "amul", "jersey", "gsk"],
			answer: 0
		}
	];

	return {
		getQuestion: function(id) {
			if(id < questions.length) {
				return questions[id];
			} else {
				return false;
			}
		}
	};
});
