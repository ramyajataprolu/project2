import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.BlogDAO;
import com.niit.model.Collab_Blog;

public class BlogTest {
	
	public static void main(String[] args)
		{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.ChatCollab");
		context.refresh();
		Collab_Blog cb=(Collab_Blog) context.getBean("collab_blog");
		BlogDAO blogDAO=(BlogDAO) context.getBean("blogDAO");
		
		cb.setId("101");
		cb.setTitle("blog1");
		cb.setDescription("about blog1");
		cb.setUser_id("u_101");
		blogDAO.saveOrUpdate(cb);
		}
	
	}
