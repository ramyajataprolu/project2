package com.niit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.ChatBlog;

@Repository
@Transactional
public class ChatBlogDaoImpl implements ChatBlogDao{
	
	@Autowired 
	private SessionFactory sessionFactory;
	
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public void createNewBlog(ChatBlog blog) {
		
	Session session= sessionFactory.getCurrentSession();
	Transaction t = session.beginTransaction();
	System.out.println(blog);
	session.saveOrUpdate(blog);
	t.commit();
	}
	
	public List<ChatBlog> getBlogList(String bUserName) {
		@SuppressWarnings("unchecked")
		Session session=this.sessionFactory.getCurrentSession();
		 @SuppressWarnings("unchecked")
		List<ChatBlog> blog = (List<ChatBlog>) sessionFactory.getCurrentSession().createCriteria(ChatBlog.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		 return blog;
	}
	
	public ChatBlog getBlogById(int bid) {
		Session session=this.sessionFactory.getCurrentSession();
		ChatBlog b=(ChatBlog) session.load(ChatBlog.class,bid);
		System.out.println("data of blog by id="+b);
		return b;	
	}
	
	public ChatBlog getBlogByName(String bname) {
		System.out.println("getting data in dao based on name");
		Session session=this.sessionFactory.getCurrentSession();
		ChatBlog blog = (ChatBlog) session.get(ChatBlog.class, bname);
		return blog;
	}
	
	@Transactional
	public void delete(int bid) {
		
		ChatBlog blog = new ChatBlog();
		sessionFactory.getCurrentSession().delete(blog);
		System.out.println("deleted success");
	}
	
	List<ChatBlog> blogs;
	@SuppressWarnings("unchecked")
	public List<ChatBlog> getBlog()
	{
		System.out.println("DAO Implementation");
		Session ss1 = sessionFactory.openSession();
		Query qry = ss1.createQuery("from Blog");
		System.out.println(qry.toString());
		blogs = (List<ChatBlog>)qry.list();
		return blogs;
	}

	

}
