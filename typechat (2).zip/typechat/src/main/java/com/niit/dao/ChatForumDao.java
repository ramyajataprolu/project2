package com.niit.dao;

import java.util.List;

import com.niit.model.ChatForum;

public interface ChatForumDao {
	
	public void createNewForum(ChatForum f);
	public List<ChatForum> getForumList(String UserName);
	public void delete(int fid);
	public List<ChatForum> getForum();

}
