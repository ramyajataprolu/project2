package com.niit.dao;

import java.util.List;

import com.niit.model.ChatBlog;

public interface ChatBlogDao {
	

	public void createNewBlog(ChatBlog blog);
	public List<ChatBlog> getBlogList(String bUserName);
	public ChatBlog getBlogById(int bid);
	public ChatBlog getBlogByName(String bname);
	public void delete(int bid);
	public List<ChatBlog> getBlog();

}
