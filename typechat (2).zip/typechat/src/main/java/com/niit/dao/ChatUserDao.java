package com.niit.dao;

import java.util.List;

import com.niit.model.ChatUser;

public interface ChatUserDao {
	

	public void saveOrUpdate(ChatUser user);
	public ChatUser getUserById(int userid);
	public  List<ChatUser> list();
	public ChatUser getUserByname(String username);

}
