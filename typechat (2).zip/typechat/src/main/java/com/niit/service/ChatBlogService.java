package com.niit.service;

import java.util.List;

import com.niit.model.ChatBlog;

public interface ChatBlogService {
	
	public void createNewBlog(ChatBlog blog);
	public List<ChatBlog> getBlogList(String bUserName);
	public ChatBlog getBlogById(int bid);
	public ChatBlog getBlogByName(String bname);
	public List<ChatBlog> getBlog();


}
