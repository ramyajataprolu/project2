package com.niit.service;

import java.util.List;

import com.niit.model.ChatUser;

public interface ChatUserService {
	
	public void saveOrUpdate(ChatUser user);
	public ChatUser getUserById(int userid);
	public  List<ChatUser> list();
	public ChatUser getUserByname(String username);

}
