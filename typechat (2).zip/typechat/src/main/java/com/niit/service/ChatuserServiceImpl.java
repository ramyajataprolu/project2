package com.niit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.dao.ChatUserDao;
import com.niit.model.ChatUser;


@Service
public class ChatuserServiceImpl implements ChatUserService {
	

	@Autowired
	private ChatUserDao userdao;
	
	@Transactional
	public void setUserDao(ChatUserDao userdao)
	{
		this.userdao=userdao;
	}
	@Transactional
	public void saveOrUpdate(ChatUser user) {
		userdao.saveOrUpdate(user);
		
	}

	@Transactional
	public ChatUser getUserById(int userid) {
		
		return userdao.getUserById(userid);
	}

	@Transactional
	public List<ChatUser> list() {
		
		return userdao.list();
	}

	@Transactional
	public ChatUser getUserByname(String username) {
		
		return userdao.getUserByname(username);
	}

}
