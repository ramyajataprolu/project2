package com.niit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.dao.ChatBlogDao;

import com.niit.model.ChatBlog;



@Service
public class ChatBlogServiceImpl implements ChatBlogService{
	
	@Autowired
	ChatBlogDao blogdao;
	
	public void createNewBlog(ChatBlog blog)
	{
		blogdao.createNewBlog(blog);
	}
	public List<ChatBlog> getBlogList(String bUserName)
	{
		return blogdao.getBlogList(bUserName);
	}
	public ChatBlog getBlogById(int bid)
	{
		return new ChatBlog();
	}
	public ChatBlog getBlogByName(String bname)
	{
		return new ChatBlog();
	}
	public List<ChatBlog> getBlog()
	{
		System.out.println("i am in blog serivce");
		return blogdao.getBlog();
	}
	

}
