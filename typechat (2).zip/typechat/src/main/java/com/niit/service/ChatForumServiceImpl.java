package com.niit.service;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.dao.ChatForumDao;
import com.niit.model.ChatForum;



@Service
public class ChatForumServiceImpl implements ChatForumService{
	

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	ChatForumDao forumdao;
	
public ChatForumServiceImpl(){}
	
	public ChatForumServiceImpl(SessionFactory sf){
		this.sessionFactory=sf;
	}
	
	public void createNewForum(ChatForum f) {
		forumdao.createNewForum(f);
		
	}

	public List<ChatForum> getForumList(String UserName) {
		
		return forumdao.getForumList(UserName);
		
	}
	
	public void delete(int fid) {
		forumdao.delete(fid);
		
	}
	
	public List<ChatForum> getForum()
	{
		System.out.println("I am in forum service");
		return forumdao.getForum();
	}

}
