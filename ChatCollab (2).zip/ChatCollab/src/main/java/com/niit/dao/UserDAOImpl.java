package com.niit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.CollabUser;
@Repository("userDAO")
public class UserDAOImpl implements UserDAO {
	public UserDAOImpl()
	{
	}
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public UserDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}

	@Transactional
	public List<CollabUser> list() {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<CollabUser> list=(List<CollabUser>) sessionFactory.getCurrentSession()
				.createCriteria(CollabUser.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return list;
	}

	public void saveOrUpdate(CollabUser collabUser) {
		System.out.println("am in userDAO saveOrUpdate");
		
		sessionFactory.getCurrentSession().saveOrUpdate(collabUser);
	}

}
