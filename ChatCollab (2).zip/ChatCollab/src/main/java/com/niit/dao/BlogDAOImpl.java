package com.niit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Collab_Blog;

@Repository("blogDAO")
public class BlogDAOImpl implements BlogDAO {
	public BlogDAOImpl()
	{
		
	}

	@Autowired
	private SessionFactory sessionFactory;
	
	public BlogDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}

	@Transactional
	public List<Collab_Blog> list() {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<Collab_Blog> list=(List<Collab_Blog>) sessionFactory.openSession()
				.createCriteria(Collab_Blog.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return list;
	}

	@Transactional
	public void saveOrUpdate(Collab_Blog collab_blog) {
		// TODO Auto-generated method stub
		System.out.println("in save or update");
		sessionFactory.getCurrentSession().saveOrUpdate(collab_blog);
		System.out.println("in save or update of daoimpl");
		
	}
	
}
