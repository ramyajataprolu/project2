package com.niit.dao;

import java.util.List;

import com.niit.model.CollabUser;


public interface UserDAO {
	public List<CollabUser> list();
	public void  saveOrUpdate(CollabUser collabUser);

}
