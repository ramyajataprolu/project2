package com.niit.dao;

import java.util.List;

import com.niit.model.Collab_Blog;

public interface BlogDAO {
	
  public List<Collab_Blog> list();
	public void  saveOrUpdate(Collab_Blog collab_blog);
}
