import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.UserDAO;
import com.niit.model.CollabUser;

public class UserTest {
	
	private CollabUser collabUser;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private AnnotationConfigApplicationContext context;
	@Test
	public void test() {
		fail("Not yet implemented");
	}

	@Before
	public void init()
	{
	
	collabUser= new CollabUser();
	 context=new AnnotationConfigApplicationContext();
	context.scan("com.niit.CollabChat");
	context.refresh();
	System.out.println("************");
	/*CollabUser cb=(CollabUser) context.getBean("collabUser");
	*/
	System.out.println("before entering values");
	collabUser.setId("101");
	collabUser.setName("user1");
	collabUser.setPassword("1234");
	collabUser.setEmail("123@tat.com");
	collabUser.setMobile("122456");
	collabUser.setStatus('1');
	collabUser.setReason("nop reason");
	System.out.println("entering values");
	 userDAO=(UserDAO) context.getBean("userDAO");
	userDAO.saveOrUpdate(collabUser);
	
	}


}
