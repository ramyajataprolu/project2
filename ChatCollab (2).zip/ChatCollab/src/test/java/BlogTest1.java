import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.BlogDAO;
import com.niit.model.Collab_Blog;

public class BlogTest1 {
	static AnnotationConfigApplicationContext context;
	
		
	
public static void main(String[] args) {
		
	@SuppressWarnings("resource")
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	context.scan("com.niit");
	context.refresh();
	Collab_Blog cb=(Collab_Blog)context.getBean("collab_Blog");
	
	 System.out.println("after daos");
	
	cb.setId("10");
	cb.setTitle("NIIT");
	cb.setDescription("NIIT");
	cb.setUser_id("u_101");
	BlogDAO blogDAO=(BlogDAO) context.getBean("blogDAO");
	System.out.println("entering values");
	blogDAO.saveOrUpdate(cb);
	System.out.println("after save or update");
		
		
		
		
	}

}
